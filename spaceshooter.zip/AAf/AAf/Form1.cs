﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AAf
{
    public partial class Form1 : Form
    {
        bool goLeft, goRight, shooting, isGameOver;
        int score;
        int playerSpeed = 35;
        int enemySpeed;
        int bulletSpeed;
        int boss1Speed = 8;
        int coin;
        int boss1Damage = 20;
        int heart;
        //money
        int moneySpeed;
        int money2Speed;

        //ebullet
        int jetSpeed;
        int jtSpeed;
        int tjSpeed;
        int expSpeed;
        ////
        //

        int emdadSpeed;
        int itemsSpeed;
        int SUNSpeed;
        int MONSpeed;

        
        Random rnd = new Random();



        public Form1()
        {
            InitializeComponent();
            resetGame();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void maingameTimerEvent(object sender, EventArgs e)
        {

            txtScore.Text = score.ToString();
            txtCoin.Text = coin.ToString();
            txtHeart.Text = heart.ToString();

            emdad1.Top += emdadSpeed;


            money.Top += moneySpeed;
            money2.Top += money2Speed;


            enemyOne.Top += enemySpeed;
            enemyTwo.Top += enemySpeed;
            enemyThree.Top += enemySpeed;
            enemyFour.Top += enemySpeed;
            enemyFive.Top += enemySpeed;
            enemySix.Top += enemySpeed;
            boss1.Top += boss1Speed;



            if (fire.Top > 1038)
            {
                fire.Top = -5000;
                fire.Left = rnd.Next(15, 676);
            }
            if (pbullet.Top > 1038)
            {
                pbullet.Top = -10000;
                pbullet.Left = rnd.Next(15, 676);
            }
            if (Magic.Top > 1038)
            {
                Magic.Top = -14000;
                Magic.Left = rnd.Next(15, 676);
            }
            if (BlackMagic.Top > 1038)
            {
                BlackMagic.Top = -18000;
                BlackMagic.Left = rnd.Next(15, 676);
            }
            if (Nplayer2.Top > 1038)
            {
                Nplayer2.Top = -8000;
                Nplayer2.Left = rnd.Next(15, 676);
            }
            if (Nplayer1.Top > 1038)
            {
                Nplayer1.Top = -16000;
                Nplayer1.Left = rnd.Next(15, 676);
            }
            



            bulletz.Top += jetSpeed;
            bulletz2.Top += jetSpeed;
            bulletz3.Top += jetSpeed;
            bulletz4.Top += jetSpeed;
            bulletz5.Top += jetSpeed;
            bulletz6.Top += jetSpeed;
            bulletz7.Top += jtSpeed;
            bulletz8.Top += jtSpeed;
            bulletz9.Top += jtSpeed;
            bulletz10.Top += jtSpeed;
            bulletz11.Top += jtSpeed;
            bulletz12.Top += jtSpeed;
            bulletz13.Top += tjSpeed;
            bulletz14.Top += tjSpeed;
            bulletz15.Top += tjSpeed;
            bulletz16.Top += tjSpeed;
            bulletz17.Top += tjSpeed;
            bulletz18.Top += tjSpeed;


            sun.Top += SUNSpeed;
           


            exp1.Top += expSpeed;
            exp2.Top += expSpeed;
            exp3.Top += expSpeed;
            exp4.Top += expSpeed;


            fire.Top += itemsSpeed;
            pbullet.Top += itemsSpeed;
            Magic.Top += itemsSpeed;
            BlackMagic.Top += itemsSpeed;
            Nplayer1.Top += itemsSpeed;
            Nplayer2.Top += itemsSpeed;
            




            
            



            if (money.Top > 1038)
            {
                money.Top = -1660;
                money.Left = rnd.Next(15, 676);
            }
            if (money2.Top > 1038)
            {
                money.Top = -4990;
                money.Left = rnd.Next(15, 676);
            }


            if (boss1.Top > -50)
            {
                boss1Speed = 0;
            }

            //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            if (emdad1.Top > 1030)
            {
                emdad1.Top = -13000;
                emdad1.Left = rnd.Next(15, 680);


            }


            if (enemyOne.Top > 1030)
            {
                heart -= 1;
                enemyOne.Top = -1350;
                enemyOne.Left = rnd.Next(237, 271);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }
            }
            if (enemyTwo.Top > 1030)
            {
                heart -= 1;
                enemyTwo.Top = -1700;
                enemyTwo.Left = rnd.Next(201, 237);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }
            }
            if (enemyThree.Top > 1030)
            {
                heart -= 1;
                enemyThree.Top = -700;
                enemyThree.Left = rnd.Next(93, 129);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }
            }
            if (enemyFour.Top > 1030)
            {
                heart -= 1;
                enemyFour.Top = -2500;
                enemyFour.Left = rnd.Next(305, 341);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }
            }
            if (enemyFive.Top > 1030)
            {
                heart -= 1;
                enemyFive.Top = -1910;
                enemyFive.Left = rnd.Next(271, 305);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }
            }
            if (enemySix.Top > 1030)
            {
                heart -= 1;
                enemySix.Top = -2350;
                enemySix.Left = rnd.Next(341, 377);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }
            }

            if (boss1.Top > -50)
            {
                boss1Speed = 0;
            }




            if (bulletz.Top > 1030)
            {
                bulletz.Top = -100;
                bulletz.Left = rnd.Next(15, 57);
                shooting = false;
            }

            if (bulletz2.Top > 1030)
            {
                bulletz2.Top = -400;
                bulletz2.Left = rnd.Next(57, 93);
                shooting = false;
            }
            if (bulletz3.Top > 1030)
            {
                bulletz3.Top = -700;
                bulletz3.Left = rnd.Next(93, 129);
                shooting = false;
            }
            if (bulletz4.Top > 1030)

            {
                bulletz4.Top = -250;
                bulletz4.Left = rnd.Next(129, 165);
                shooting = false;
            }
            if (bulletz5.Top > 1030)
            {
                bulletz5.Top = -1000;
                bulletz5.Left = rnd.Next(165, 201);
                shooting = false;
            }
            if (bulletz6.Top > 1030)
            {
                bulletz6.Top = -1700;
                bulletz6.Left = rnd.Next(201, 237);
                shooting = false;
            }
            if (bulletz7.Top > 1030)
            {
                bulletz7.Top = -1350;
                bulletz7.Left = rnd.Next(237, 271);
                shooting = false;
            }
            if (bulletz8.Top > 1030)
            {
                bulletz8.Top = -1910;
                bulletz8.Left = rnd.Next(271, 305);
                shooting = false;
            }
            if (bulletz9.Top > 1030)
            {
                bulletz9.Top = -2500;
                bulletz9.Left = rnd.Next(305, 341);
                shooting = false;
            }
            if (bulletz10.Top > 1030)
            {
                bulletz10.Top = -2350;
                bulletz10.Left = rnd.Next(341, 377);
                shooting = false;
            }
            if (bulletz11.Top > 1030)
            {
                bulletz11.Top = -2850;
                bulletz11.Left = rnd.Next(377, 411);
                shooting = false;
            }
            if (bulletz12.Top > 1030)
            {
                bulletz12.Top = -3050;
                bulletz12.Top = -4270;
                bulletz12.Left = rnd.Next(411, 447);
                shooting = false;
            }
            if (bulletz13.Top > 1030)
            {
                bulletz13.Top = -3480;
                bulletz13.Left = rnd.Next(447, 483);
                shooting = false;
            }
            if (bulletz14.Top > 1030)
            {
                bulletz14.Top = -3930;
                bulletz14.Left = rnd.Next(483, 519);
                shooting = false;
            }
            if (bulletz15.Top > 1030)
            {
                bulletz15.Top = -4490;
                bulletz15.Left = rnd.Next(519, 555);
                shooting = false;
            }
            if (bulletz16.Top > 1030)
            {
                bulletz16.Top = -3260;
                bulletz16.Left = rnd.Next(555, 591);
                shooting = false;
            }
            if (bulletz17.Top > 1030)
            {
                bulletz17.Top = -3780;
                bulletz17.Left = rnd.Next(591, 627);
                shooting = false;
            }
            if (bulletz18.Top > 1030)
            {
                bulletz18.Top = -4710;
                bulletz18.Left = rnd.Next(627, 675);
                shooting = false;
            }





            //player movement logic starts

            if (goLeft == true && player.Left > 0)
            {
                player.Left -= playerSpeed;
            }
            if (goRight == true && player.Left < 841)
            {
                player.Left += playerSpeed;
            }

            //player movement logic ends

            if (shooting == true)
            {
                bulletSpeed = 90;
                bullet.Top -= bulletSpeed;
            }
            else
            {
                bullet.Left = -200;
                bulletSpeed = 0;
            }
            if (bullet.Top < -20)
            {
                shooting = false;
            }

            /////++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

            if (player.Bounds.IntersectsWith(money.Bounds))
            {
                coin += 1;
                money.Top = -860;
                money.Left = rnd.Next(15, 675);
                shooting = false;
            }
            if (player.Bounds.IntersectsWith(money2.Bounds))
            {
                coin += 1;
                money2.Top = -2890;
                money2.Left = rnd.Next(15, 675);
                shooting = false;
            }


            ////+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


            if (bullet.Bounds.IntersectsWith(enemyOne.Bounds))
            {
                score += 2;
                enemyOne.Top = -450;
                enemyOne.Left = rnd.Next(15, 680);
                shooting = false;

            }
            if (bullet.Bounds.IntersectsWith(enemyTwo.Bounds))
            {
                score += 2;
                enemyTwo.Top = -650;
                enemyTwo.Left = rnd.Next(15, 680);
                shooting = false;
            }
            if (bullet.Bounds.IntersectsWith(enemyThree.Bounds))
            {
                score += 2;
                enemyThree.Top = -750;
                enemyThree.Left = rnd.Next(15, 680);
                shooting = false;
            }
            if (bullet.Bounds.IntersectsWith(enemyFour.Bounds))
            {
                score += 2;
                enemyFour.Top = -850;
                enemyFour.Left = rnd.Next(15, 680);
                shooting = false;
            }
            if (bullet.Bounds.IntersectsWith(enemyFive.Bounds))
            {
                score += 2;
                enemyFive.Top = -950;
                enemyFive.Left = rnd.Next(15, 680);
                shooting = false;
            }
            if (bullet.Bounds.IntersectsWith(enemySix.Bounds))
            {
                score += 2;
                enemySix.Top = -1050;
                enemySix.Left = rnd.Next(15, 680);
                shooting = false;
            }
            //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

            if (enemyOne.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                enemyOne.Top = -1490;
                enemyOne.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart == 0)
                {
                    gameOver();
                }
            }
            if (enemyTwo.Bounds.IntersectsWith(player.Bounds))
            {
                heart -= 1;
                enemyTwo.Top = -820;
                enemyTwo.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart == 0)
                {
                    gameOver();
                }
            }
            if (enemyThree.Bounds.IntersectsWith(player.Bounds))
            {
                heart -= 1;
                enemyThree.Top = -1680;
                enemyThree.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart == 0)
                {
                    gameOver();
                }
            }
            if (enemyFour.Bounds.IntersectsWith(player.Bounds))
            {
                heart -= 1;
                enemyFour.Top = -510;
                enemyFour.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart == 0)
                {
                    gameOver();
                }
            }
            if (enemyFive.Bounds.IntersectsWith(player.Bounds))
            {
                heart -= 1;
                enemyFive.Top = -1270;
                enemyFive.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart == 0)
                {
                    gameOver();
                }
            }
            if (enemySix.Bounds.IntersectsWith(player.Bounds))
            {
                heart -= 1;
                enemySix.Top = -230;
                enemySix.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart == 0)
                {
                    gameOver();
                }
            }



            if (bullet.Bounds.IntersectsWith(boss1.Bounds))
            {
                boss1Damage -= 1;
                shooting = false;
                if (boss1Damage < 1)
                {
                    Win();
                }

            }

            ////+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            //
            if (sun.Top > 200)
            {
                SUNSpeed = -4;
            }
            

            if (emdad1.Bounds.IntersectsWith(player.Bounds))
            {
                heart += 2;
                emdad1.Top = -7300;
                emdad1.Left = rnd.Next(15, 680);
            }


            ////+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

            if (bulletz.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                bulletz.Top = -1230;
                bulletz.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }

            }
            if (bulletz2.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                bulletz2.Top = -530;
                bulletz2.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }

            }
            if (bulletz3.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                bulletz3.Top = -230;
                bulletz3.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }

            }
            if (bulletz3.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                bulletz3.Top = -2530;
                bulletz3.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }

            }
            if (bulletz4.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                bulletz4.Top = -2870;
                bulletz4.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }

            }
            if (bulletz5.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                bulletz5.Top = -1560;
                bulletz5.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }

            }
            if (bulletz6.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                bulletz6.Top = -830;
                bulletz6.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }

            }
            if (bulletz7.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                bulletz7.Top = -1910;
                bulletz7.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }

            }
            if (bulletz8.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                bulletz8.Top = -1740;
                bulletz8.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }

            }
            if (bulletz9.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                bulletz9.Top = -2330;
                bulletz9.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }

            }
            if (bulletz10.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                bulletz10.Top = -2570;
                bulletz10.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }

            }
            if (bulletz11.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                bulletz11.Top = -3100;
                bulletz11.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }

            }
            if (bulletz12.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                bulletz12.Top = -3390;
                bulletz12.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }

            }
            if (bulletz13.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                bulletz13.Top = -3620;
                bulletz13.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }

            }
            if (bulletz14.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                bulletz14.Top = -3900;
                bulletz14.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }

            }
            if (bulletz15.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                bulletz15.Top = -4220;
                bulletz15.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }

            }
            if (bulletz16.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                bulletz16.Top = -4490;
                bulletz16.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }

            }
            if (bulletz17.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                bulletz17.Top = -4699;
                bulletz17.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }

            }
            if (bulletz18.Bounds.IntersectsWith(player.Bounds))
            {

                heart -= 1;
                bulletz18.Top = -4860;
                bulletz18.Left = rnd.Next(15, 680);
                shooting = false;
                if (heart < 1)
                {
                    gameOver();
                }


            }


            if (bulletz.Bounds.IntersectsWith(bullet.Bounds))
            {

                bulletz.Top = -1230;
                bulletz.Left = rnd.Next(15, 680);
                shooting = false;

            }
            if (bulletz2.Bounds.IntersectsWith(bullet.Bounds))
            {
                bulletz2.Top = -530;
                bulletz2.Left = rnd.Next(15, 680);
                shooting = false;

            }
            if (bulletz3.Bounds.IntersectsWith(bullet.Bounds))
            {


                bulletz3.Top = -230;
                bulletz3.Left = rnd.Next(15, 680);
                shooting = false;

            }
            if (bulletz3.Bounds.IntersectsWith(bullet.Bounds))
            {


                bulletz3.Top = -2830;
                bulletz3.Left = rnd.Next(15, 680);
                shooting = false;

            }
            if (bulletz4.Bounds.IntersectsWith(bullet.Bounds))
            {


                bulletz4.Top = -2070;
                bulletz4.Left = rnd.Next(15, 680);
                shooting = false;

            }
            if (bulletz5.Bounds.IntersectsWith(bullet.Bounds))
            {


                bulletz5.Top = -1460;
                bulletz5.Left = rnd.Next(15, 680);
                shooting = false;

            }
            if (bulletz6.Bounds.IntersectsWith(bullet.Bounds))
            {


                bulletz6.Top = -830;
                bulletz6.Left = rnd.Next(15, 680);
                shooting = false;

            }
            if (bulletz7.Bounds.IntersectsWith(bullet.Bounds))
            {


                bulletz7.Top = -1610;
                bulletz7.Left = rnd.Next(15, 680);
                shooting = false;


            }
            if (bulletz8.Bounds.IntersectsWith(bullet.Bounds))
            {


                bulletz8.Top = -1940;
                bulletz8.Left = rnd.Next(15, 680);
                shooting = false;

            }
            if (bulletz9.Bounds.IntersectsWith(bullet.Bounds))
            {


                bulletz9.Top = -2430;
                bulletz9.Left = rnd.Next(15, 680);
                shooting = false;

            }
            if (bulletz10.Bounds.IntersectsWith(bullet.Bounds))
            {


                bulletz10.Top = -2770;
                bulletz10.Left = rnd.Next(15, 680);
                shooting = false;

            }
            if (bulletz11.Bounds.IntersectsWith(bullet.Bounds))
            {


                bulletz11.Top = -3000;
                bulletz11.Left = rnd.Next(15, 680);
                shooting = false;

            }
            if (bulletz12.Bounds.IntersectsWith(bullet.Bounds))
            {

                bulletz12.Top = -3290;
                bulletz12.Left = rnd.Next(15, 680);
                shooting = false;

            }
            if (bulletz13.Bounds.IntersectsWith(bullet.Bounds))
            {


                bulletz13.Top = -3820;
                bulletz13.Left = rnd.Next(15, 680);
                shooting = false;

            }
            if (bulletz14.Bounds.IntersectsWith(bullet.Bounds))
            {

                bulletz14.Top = -3500;
                bulletz14.Left = rnd.Next(15, 680);
                shooting = false;

            }
            if (bulletz15.Bounds.IntersectsWith(bullet.Bounds))
            {

                bulletz15.Top = -4020;
                bulletz15.Left = rnd.Next(15, 680);
                shooting = false;

            }
            if (bulletz16.Bounds.IntersectsWith(bullet.Bounds))
            {


                bulletz16.Top = -4690;
                bulletz16.Left = rnd.Next(15, 680);
                shooting = false;

            }
            if (bulletz17.Bounds.IntersectsWith(bullet.Bounds))
            {

                bulletz17.Top = -4999;
                bulletz17.Left = rnd.Next(15, 680);
                shooting = false;

            }
            if (bulletz18.Bounds.IntersectsWith(bullet.Bounds))
            {


                bulletz18.Top = -4260;
                bulletz18.Left = rnd.Next(15, 680);
                shooting = false;

            }




            if (exp1.Top > 1030)
            {
                exp1.Top = -1800;
                exp1.Left = rnd.Next(120, 120);
                shooting = false;

            }
            if (exp1.Bounds.IntersectsWith(player.Bounds))
            {
                heart -= 2;
                shooting = false;
                exp1.Top = -1800;
                exp1.Left = rnd.Next(120, 120);
                exp2.Top = -1800;
                exp2.Left = rnd.Next(350, 350);
                exp3.Top = -1800;
                exp3.Left = rnd.Next(420, 420);
                exp4.Top = -1800;
                exp4.Left = rnd.Next(630, 630);
                if (heart == 0)
                {
                    gameOver();
                }
            }
            if (exp2.Top > 1030)
            {
                exp2.Top = -1800;
                exp2.Left = rnd.Next(340, 340);
                shooting = false;
            }
            if (exp2.Bounds.IntersectsWith(player.Bounds))
            {
                heart -= 2;
                shooting = false;
                exp1.Top = -1800;
                exp1.Left = rnd.Next(120, 120);
                exp2.Top = -1800;
                exp2.Left = rnd.Next(350, 350);
                exp3.Top = -1800;
                exp3.Left = rnd.Next(420, 420);
                exp4.Top = -1800;
                exp4.Left = rnd.Next(630, 630);
                if (heart == 0)
                {
                    gameOver();
                }
            }
            if (exp3.Top > 1030)
            {
                exp3.Top = -1800;
                exp3.Left = rnd.Next(420, 420);
                shooting = false;

            }
            if (exp3.Bounds.IntersectsWith(player.Bounds))
            {
                heart -= 2;
                shooting = false;
                exp1.Top = -1800;
                exp1.Left = rnd.Next(120, 120);
                exp2.Top = -1800;
                exp2.Left = rnd.Next(350, 350);
                exp3.Top = -1800;
                exp3.Left = rnd.Next(420, 420);
                exp4.Top = -1800;
                exp4.Left = rnd.Next(630, 630);
                if (heart == 0)
                {
                    gameOver();
                }

            }
            if (exp4.Top > 1030)
            {
                exp4.Top = -1800;
                exp4.Left = rnd.Next(610, 610);
                shooting = false;

            }
            if (exp4.Bounds.IntersectsWith(player.Bounds))
            {
                heart -= 2;
                shooting = false;
                exp1.Top = -1800;
                exp1.Left = rnd.Next(120, 120);
                exp2.Top = -1800;
                exp2.Left = rnd.Next(350, 350);
                exp3.Top = -1800;
                exp3.Left = rnd.Next(420, 420);
                exp4.Top = -1800;
                exp4.Left = rnd.Next(630, 630);
                if (heart == 0)
                {
                    gameOver();
                }
            }



            if(fire.Bounds.IntersectsWith(player.Bounds)) {
                bullet.Image = AAf.Properties.Resources.kisspng_flame_fireworks_stock_photography_image_dakota_fire_hole_lakeshore_rv_blog_5bf3b784778586_7908807515426988844896;
            }
            if (pbullet.Bounds.IntersectsWith(player.Bounds))
            {
                bullet.Image = AAf.Properties.Resources.kisspng_glass_transparency_and_translucency_sphere_crystal_magic_ball_5a9710ca74fa97_8178885115198496744792;
            }
            if (Magic.Bounds.IntersectsWith(player.Bounds))
            {
                bullet.Image = AAf.Properties.Resources.kisspng_clear_aligners_dental_braces_orthodontics_dentistr_flame_sun_clip_art_at_clker_com_vector_clip_art_5bc4f2696d71c6_4466135115396337694483;
            }
            if (BlackMagic.Bounds.IntersectsWith(player.Bounds))
            {
                bullet.Image = AAf.Properties.Resources.kisspng_magic_circle_world_of_warcraft_alchemy_png_avatan_plus_5cba16984e9047_5349552215556993523218;
            }
            if (Nplayer1.Bounds.IntersectsWith(player.Bounds))
            {
                player.Image = AAf.Properties.Resources.kisspng_starcraft_ii_legacy_of_the_void_protoss_wikia_zer_zerg_5b31b2daa114e3_5278638215299837066598;
            }
            if (Nplayer2.Bounds.IntersectsWith(player.Bounds))
            {
                player.Image = AAf.Properties.Resources.kisspng_starcraft_ii_wings_of_liberty_protoss_art_5b14042e2894a3_3478585315280384461662;
            }

            


            ////+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            if (score == 15)
            {
                enemySpeed = 8;
            }
            if (score == 25)
            {
                enemySpeed = 9;
            }
            if (score == 39)
            {
                enemySpeed = 10;
            }
            if (score == 58)
            {
                enemySpeed = 11;
            }
            if (score == 70)
            {
                enemySpeed = 12;
            }

            if (score == 78)
            {
                enemySpeed = 0;
                boss1Speed = 10;
                jetSpeed = 13;
                tjSpeed = 15;
                jtSpeed = 17;
                playerSpeed = 18;
                emdadSpeed = 7;
                expSpeed = 10;
                moneySpeed = 0;
                money2Speed = 0;
            }



            if (boss1.Top > -50)
            {
                boss1Speed = 0;
            }



        }

        private void keyisdown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                goLeft = true;
            }
            if (e.KeyCode == Keys.Right)
            {
                goRight = true;
            }
        }

        private void keyisup(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                goLeft = false;
            }
            if (e.KeyCode == Keys.Right)
            {
                goRight = false;
            }
            if (e.KeyCode == Keys.Space && shooting == false)
            {
                shooting = true;

                bullet.Top = player.Top - 10;
                bullet.Left = player.Left + (player.Width / 2);
            }
            if (e.KeyCode == Keys.Enter && isGameOver == true)
            {

                resetGame();

            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void resetGame()
        {
            gameTimer.Start();
            expSpeed = 0;
            emdadSpeed = 6;
            jtSpeed = 0;
            tjSpeed = 0;
            jetSpeed = 0;
            itemsSpeed = 8;
            SUNSpeed = 4;
            
            enemySpeed = 7;
            boss1Speed = 0;
            moneySpeed = 6;
            money2Speed = 6;
            coin = 0;
            heart = 6;




            sun.Top = rnd.Next(1000, 2000) * -1;
            sun.Left = rnd.Next(770,770);



            fire.Top = rnd.Next(5000, 5000) * -1;
            fire.Left = rnd.Next(15, 676);



            pbullet.Top = rnd.Next(7000, 7000) * -1;
            pbullet.Left = rnd.Next(15, 676);



            Magic.Top = rnd.Next(9000, 9000) * -1;
            Magic.Left = rnd.Next(15, 676);

            BlackMagic.Top = rnd.Next(11000, 11000) * -1;
            BlackMagic.Left = rnd.Next(15, 676);

            Nplayer2.Top = rnd.Next(6000, 6000) * -1;
            Nplayer2.Left = rnd.Next(15, 676);

            Nplayer1.Top = rnd.Next(10000, 10000) * -1;
            Nplayer1.Left = rnd.Next(15, 676);




            money.Top = rnd.Next(3000, 4000);
            money2.Top = rnd.Next(8000, 9000);
            emdad1.Top = rnd.Next(4500, 6700);


            money.Left = rnd.Next(15, 675);
            money2.Left = rnd.Next(15, 675);
            emdad1.Left = rnd.Next(15, 670);


            enemyOne.Left = rnd.Next(10, 680);
            enemyTwo.Left = rnd.Next(10, 680);
            enemyThree.Left = rnd.Next(10, 680);
            enemyFour.Left = rnd.Next(10, 680);
            enemyFive.Left = rnd.Next(10, 680);
            enemySix.Left = rnd.Next(10, 680);



            enemyOne.Top = rnd.Next(0, 150) * -1;
            enemyTwo.Top = rnd.Next(190, 500) * -1;
            enemyThree.Top = rnd.Next(540, 850) * -1;
            enemyFour.Top = rnd.Next(890, 1320) * -1;
            enemyFive.Top = rnd.Next(1360, 1580) * -1;
            enemySix.Top = rnd.Next(1620, 1860) * -1;
            boss1.Top = rnd.Next(500, 500) * -1;


            bulletz.Left = rnd.Next(20, 57);
            bulletz2.Left = rnd.Next(57, 93);
            bulletz3.Left = rnd.Next(93, 129);
            bulletz4.Left = rnd.Next(129, 165);
            bulletz5.Left = rnd.Next(165, 201);
            bulletz6.Left = rnd.Next(201, 237);
            bulletz7.Left = rnd.Next(237, 271);
            bulletz8.Left = rnd.Next(271, 305);
            bulletz9.Left = rnd.Next(305, 341);
            bulletz10.Left = rnd.Next(341, 377);
            bulletz11.Left = rnd.Next(377, 411);
            bulletz12.Left = rnd.Next(411, 447);
            bulletz13.Left = rnd.Next(447, 483);
            bulletz14.Left = rnd.Next(483, 519);
            bulletz15.Left = rnd.Next(519, 555);
            bulletz16.Left = rnd.Next(555, 591);
            bulletz17.Left = rnd.Next(591, 627);
            bulletz18.Left = rnd.Next(627, 671);




            bulletz.Top = rnd.Next(4800, 5100) * -1;
            bulletz2.Top = rnd.Next(1000, 1300) * -1;
            bulletz3.Top = rnd.Next(600, 1000) * -1;
            bulletz4.Top = rnd.Next(3700, 4100) * -1;
            bulletz5.Top = rnd.Next(1600, 1900) * -1;
            bulletz6.Top = rnd.Next(300, 600) * -1;
            bulletz7.Top = rnd.Next(2300, 2700) * -1;
            bulletz8.Top = rnd.Next(3000, 3300) * -1;
            bulletz9.Top = rnd.Next(6300, 6700) * -1;
            bulletz10.Top = rnd.Next(4100, 4500) * -1;
            bulletz11.Top = rnd.Next(5700, 6000) * -1;
            bulletz12.Top = rnd.Next(3300, 3700) * -1;
            bulletz13.Top = rnd.Next(4500, 4800) * -1;
            bulletz14.Top = rnd.Next(5100, 5400) * -1;
            bulletz15.Top = rnd.Next(5400, 5700) * -1;
            bulletz16.Top = rnd.Next(1300, 1600) * -1;
            bulletz17.Top = rnd.Next(5400, 5700) * -1;
            bulletz18.Top = rnd.Next(3700, 4100) * -1;


            exp1.Left = rnd.Next(250, 250);
            exp2.Left = rnd.Next(330, 330);
            exp3.Left = rnd.Next(410, 410);
            exp4.Left = rnd.Next(490, 490);



            exp1.Top = rnd.Next(1800, 1800) * -1;
            exp2.Top = rnd.Next(1800, 1800) * -1;
            exp3.Top = rnd.Next(1800, 1800) * -1;
            exp4.Top = rnd.Next(1800, 1800) * -1;



            boss1Damage = 20;
            score = 0;
            bulletSpeed = 0;
            bullet.Left = 100;
            shooting = false;



            txtScore.Text = score.ToString();
            txtCoin.Text = coin.ToString();
            txtHeart.Text = heart.ToString();
        }

        private void gameOver()
        {
            isGameOver = true;
            gameTimer.Stop();
            txtScore.Text += Environment.NewLine + "Game Over!" + Environment.NewLine + "Press Enter to try again.";
        }

        private void Win()
        {
            isGameOver = false;
            gameTimer.Stop();
            txtScore.Text += Environment.NewLine + "you..Win!" + Environment.NewLine + "Press Enter to try again.";
        }
    }
}
