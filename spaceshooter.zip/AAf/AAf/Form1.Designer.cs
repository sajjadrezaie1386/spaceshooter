﻿namespace AAf
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtScore = new System.Windows.Forms.Label();
            this.gameTimer = new System.Windows.Forms.Timer(this.components);
            this.txtHeart = new System.Windows.Forms.Label();
            this.txtCoin = new System.Windows.Forms.Label();
            this.sun = new System.Windows.Forms.PictureBox();
            this.Nplayer2 = new System.Windows.Forms.PictureBox();
            this.Nplayer1 = new System.Windows.Forms.PictureBox();
            this.BlackMagic = new System.Windows.Forms.PictureBox();
            this.Magic = new System.Windows.Forms.PictureBox();
            this.pbullet = new System.Windows.Forms.PictureBox();
            this.fire = new System.Windows.Forms.PictureBox();
            this.exp4 = new System.Windows.Forms.PictureBox();
            this.exp3 = new System.Windows.Forms.PictureBox();
            this.exp2 = new System.Windows.Forms.PictureBox();
            this.exp1 = new System.Windows.Forms.PictureBox();
            this.bulletz18 = new System.Windows.Forms.PictureBox();
            this.bulletz7 = new System.Windows.Forms.PictureBox();
            this.bulletz6 = new System.Windows.Forms.PictureBox();
            this.bulletz4 = new System.Windows.Forms.PictureBox();
            this.bulletz16 = new System.Windows.Forms.PictureBox();
            this.bulletz11 = new System.Windows.Forms.PictureBox();
            this.bulletz14 = new System.Windows.Forms.PictureBox();
            this.bulletz9 = new System.Windows.Forms.PictureBox();
            this.bulletz17 = new System.Windows.Forms.PictureBox();
            this.bulletz15 = new System.Windows.Forms.PictureBox();
            this.bulletz13 = new System.Windows.Forms.PictureBox();
            this.bulletz10 = new System.Windows.Forms.PictureBox();
            this.bulletz5 = new System.Windows.Forms.PictureBox();
            this.bulletz = new System.Windows.Forms.PictureBox();
            this.bulletz8 = new System.Windows.Forms.PictureBox();
            this.bulletz12 = new System.Windows.Forms.PictureBox();
            this.bulletz2 = new System.Windows.Forms.PictureBox();
            this.bulletz3 = new System.Windows.Forms.PictureBox();
            this.money = new System.Windows.Forms.PictureBox();
            this.money2 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.emdad1 = new System.Windows.Forms.PictureBox();
            this.bullet = new System.Windows.Forms.PictureBox();
            this.player = new System.Windows.Forms.PictureBox();
            this.boss1 = new System.Windows.Forms.PictureBox();
            this.enemyThree = new System.Windows.Forms.PictureBox();
            this.enemyFour = new System.Windows.Forms.PictureBox();
            this.enemyFive = new System.Windows.Forms.PictureBox();
            this.enemySix = new System.Windows.Forms.PictureBox();
            this.enemyTwo = new System.Windows.Forms.PictureBox();
            this.enemyOne = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.sun)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Nplayer2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Nplayer1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackMagic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Magic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbullet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fire)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.exp4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.exp3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.exp2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.exp1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.money)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.money2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emdad1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bullet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.boss1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyThree)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyFour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyFive)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemySix)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyTwo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyOne)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // txtScore
            // 
            this.txtScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtScore.Location = new System.Drawing.Point(-5, 420);
            this.txtScore.Name = "txtScore";
            this.txtScore.Size = new System.Drawing.Size(885, 191);
            this.txtScore.TabIndex = 14;
            this.txtScore.Text = "0";
            this.txtScore.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // gameTimer
            // 
            this.gameTimer.Interval = 20;
            this.gameTimer.Tick += new System.EventHandler(this.maingameTimerEvent);
            // 
            // txtHeart
            // 
            this.txtHeart.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHeart.Location = new System.Drawing.Point(22, 0);
            this.txtHeart.Name = "txtHeart";
            this.txtHeart.Size = new System.Drawing.Size(41, 27);
            this.txtHeart.TabIndex = 15;
            this.txtHeart.Text = "6";
            this.txtHeart.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtCoin
            // 
            this.txtCoin.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCoin.Location = new System.Drawing.Point(22, 33);
            this.txtCoin.Name = "txtCoin";
            this.txtCoin.Size = new System.Drawing.Size(41, 27);
            this.txtCoin.TabIndex = 16;
            this.txtCoin.Text = "0";
            this.txtCoin.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // sun
            // 
            this.sun.Image = global::AAf.Properties.Resources.kisspng_circle_fruit_sun_5ab0b4f8d511b0_3030941015215301048728;
            this.sun.Location = new System.Drawing.Point(542, 243);
            this.sun.Name = "sun";
            this.sun.Size = new System.Drawing.Size(76, 79);
            this.sun.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.sun.TabIndex = 48;
            this.sun.TabStop = false;
            // 
            // Nplayer2
            // 
            this.Nplayer2.Image = global::AAf.Properties.Resources.kisspng_starcraft_ii_wings_of_liberty_protoss_art_5b14042e2894a3_3478585315280384461662;
            this.Nplayer2.Location = new System.Drawing.Point(422, 757);
            this.Nplayer2.Name = "Nplayer2";
            this.Nplayer2.Size = new System.Drawing.Size(52, 52);
            this.Nplayer2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Nplayer2.TabIndex = 47;
            this.Nplayer2.TabStop = false;
            // 
            // Nplayer1
            // 
            this.Nplayer1.Image = global::AAf.Properties.Resources.kisspng_starcraft_ii_legacy_of_the_void_protoss_wikia_zer_zerg_5b31b2daa114e3_5278638215299837066598;
            this.Nplayer1.Location = new System.Drawing.Point(356, 757);
            this.Nplayer1.Name = "Nplayer1";
            this.Nplayer1.Size = new System.Drawing.Size(48, 52);
            this.Nplayer1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Nplayer1.TabIndex = 46;
            this.Nplayer1.TabStop = false;
            // 
            // BlackMagic
            // 
            this.BlackMagic.Image = global::AAf.Properties.Resources.kisspng_magic_circle_world_of_warcraft_alchemy_png_avatan_plus_5cba16984e9047_5349552215556993523218;
            this.BlackMagic.Location = new System.Drawing.Point(484, 834);
            this.BlackMagic.Name = "BlackMagic";
            this.BlackMagic.Size = new System.Drawing.Size(41, 52);
            this.BlackMagic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BlackMagic.TabIndex = 45;
            this.BlackMagic.TabStop = false;
            // 
            // Magic
            // 
            this.Magic.Image = global::AAf.Properties.Resources.kisspng_clear_aligners_dental_braces_orthodontics_dentistr_flame_sun_clip_art_at_clker_com_vector_clip_art_5bc4f2696d71c6_4466135115396337694483;
            this.Magic.Location = new System.Drawing.Point(422, 834);
            this.Magic.Name = "Magic";
            this.Magic.Size = new System.Drawing.Size(41, 52);
            this.Magic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Magic.TabIndex = 44;
            this.Magic.TabStop = false;
            // 
            // pbullet
            // 
            this.pbullet.Image = global::AAf.Properties.Resources.kisspng_glass_transparency_and_translucency_sphere_crystal_magic_ball_5a9710ca74fa97_8178885115198496744792;
            this.pbullet.Location = new System.Drawing.Point(363, 834);
            this.pbullet.Name = "pbullet";
            this.pbullet.Size = new System.Drawing.Size(41, 52);
            this.pbullet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbullet.TabIndex = 43;
            this.pbullet.TabStop = false;
            // 
            // fire
            // 
            this.fire.Image = global::AAf.Properties.Resources.kisspng_flame_fireworks_stock_photography_image_dakota_fire_hole_lakeshore_rv_blog_5bf3b784778586_7908807515426988844896;
            this.fire.Location = new System.Drawing.Point(306, 834);
            this.fire.Name = "fire";
            this.fire.Size = new System.Drawing.Size(41, 52);
            this.fire.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fire.TabIndex = 42;
            this.fire.TabStop = false;
            // 
            // exp4
            // 
            this.exp4.Image = global::AAf.Properties.Resources.kisspng_lightning_transparency_and_translucency_light_effect_lightning_5a957625dd5400_9763501615197445499066;
            this.exp4.Location = new System.Drawing.Point(578, 559);
            this.exp4.Name = "exp4";
            this.exp4.Size = new System.Drawing.Size(62, 122);
            this.exp4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.exp4.TabIndex = 41;
            this.exp4.TabStop = false;
            // 
            // exp3
            // 
            this.exp3.Image = global::AAf.Properties.Resources.kisspng_lightning_transparency_and_translucency_light_effect_lightning_5a957625dd5400_9763501615197445499066;
            this.exp3.Location = new System.Drawing.Point(449, 559);
            this.exp3.Name = "exp3";
            this.exp3.Size = new System.Drawing.Size(62, 122);
            this.exp3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.exp3.TabIndex = 40;
            this.exp3.TabStop = false;
            // 
            // exp2
            // 
            this.exp2.Image = global::AAf.Properties.Resources.kisspng_lightning_transparency_and_translucency_light_effect_lightning_5a957625dd5400_9763501615197445499066;
            this.exp2.Location = new System.Drawing.Point(321, 559);
            this.exp2.Name = "exp2";
            this.exp2.Size = new System.Drawing.Size(62, 122);
            this.exp2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.exp2.TabIndex = 39;
            this.exp2.TabStop = false;
            // 
            // exp1
            // 
            this.exp1.Image = global::AAf.Properties.Resources.kisspng_lightning_transparency_and_translucency_light_effect_lightning_5a957625dd5400_9763501615197445499066;
            this.exp1.Location = new System.Drawing.Point(193, 559);
            this.exp1.Name = "exp1";
            this.exp1.Size = new System.Drawing.Size(62, 122);
            this.exp1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.exp1.TabIndex = 38;
            this.exp1.TabStop = false;
            // 
            // bulletz18
            // 
            this.bulletz18.Image = global::AAf.Properties.Resources.kisspng_rocket_stars_ships_planet_space_jigsaw_puzzles_gam_black_missile_rocket_5aa9c323309584_868663051521074979199;
            this.bulletz18.Location = new System.Drawing.Point(644, 450);
            this.bulletz18.Name = "bulletz18";
            this.bulletz18.Size = new System.Drawing.Size(75, 103);
            this.bulletz18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bulletz18.TabIndex = 37;
            this.bulletz18.TabStop = false;
            // 
            // bulletz7
            // 
            this.bulletz7.Image = global::AAf.Properties.Resources.kisspng_rocket_stars_ships_planet_space_jigsaw_puzzles_gam_black_missile_rocket_5aa9c323309584_868663051521074979199;
            this.bulletz7.Location = new System.Drawing.Point(112, 420);
            this.bulletz7.Name = "bulletz7";
            this.bulletz7.Size = new System.Drawing.Size(75, 103);
            this.bulletz7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bulletz7.TabIndex = 36;
            this.bulletz7.TabStop = false;
            // 
            // bulletz6
            // 
            this.bulletz6.Image = global::AAf.Properties.Resources.kisspng_rocket_stars_ships_planet_space_jigsaw_puzzles_gam_black_missile_rocket_5aa9c323309584_868663051521074979199;
            this.bulletz6.Location = new System.Drawing.Point(644, 389);
            this.bulletz6.Name = "bulletz6";
            this.bulletz6.Size = new System.Drawing.Size(75, 103);
            this.bulletz6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bulletz6.TabIndex = 35;
            this.bulletz6.TabStop = false;
            // 
            // bulletz4
            // 
            this.bulletz4.Image = global::AAf.Properties.Resources.kisspng_rocket_stars_ships_planet_space_jigsaw_puzzles_gam_black_missile_rocket_5aa9c323309584_868663051521074979199;
            this.bulletz4.Location = new System.Drawing.Point(433, 389);
            this.bulletz4.Name = "bulletz4";
            this.bulletz4.Size = new System.Drawing.Size(75, 103);
            this.bulletz4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bulletz4.TabIndex = 34;
            this.bulletz4.TabStop = false;
            // 
            // bulletz16
            // 
            this.bulletz16.Image = global::AAf.Properties.Resources.kisspng_rocket_stars_ships_planet_space_jigsaw_puzzles_gam_black_missile_rocket_5aa9c323309584_868663051521074979199;
            this.bulletz16.Location = new System.Drawing.Point(433, 450);
            this.bulletz16.Name = "bulletz16";
            this.bulletz16.Size = new System.Drawing.Size(75, 103);
            this.bulletz16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bulletz16.TabIndex = 33;
            this.bulletz16.TabStop = false;
            // 
            // bulletz11
            // 
            this.bulletz11.Image = global::AAf.Properties.Resources.kisspng_rocket_stars_ships_planet_space_jigsaw_puzzles_gam_black_missile_rocket_5aa9c323309584_868663051521074979199;
            this.bulletz11.Location = new System.Drawing.Point(542, 420);
            this.bulletz11.Name = "bulletz11";
            this.bulletz11.Size = new System.Drawing.Size(75, 103);
            this.bulletz11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bulletz11.TabIndex = 32;
            this.bulletz11.TabStop = false;
            // 
            // bulletz14
            // 
            this.bulletz14.Image = global::AAf.Properties.Resources.kisspng_rocket_stars_ships_planet_space_jigsaw_puzzles_gam_black_missile_rocket_5aa9c323309584_868663051521074979199;
            this.bulletz14.Location = new System.Drawing.Point(217, 450);
            this.bulletz14.Name = "bulletz14";
            this.bulletz14.Size = new System.Drawing.Size(75, 103);
            this.bulletz14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bulletz14.TabIndex = 31;
            this.bulletz14.TabStop = false;
            // 
            // bulletz9
            // 
            this.bulletz9.Image = global::AAf.Properties.Resources.kisspng_rocket_stars_ships_planet_space_jigsaw_puzzles_gam_black_missile_rocket_5aa9c323309584_868663051521074979199;
            this.bulletz9.Location = new System.Drawing.Point(324, 420);
            this.bulletz9.Name = "bulletz9";
            this.bulletz9.Size = new System.Drawing.Size(75, 103);
            this.bulletz9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bulletz9.TabIndex = 30;
            this.bulletz9.TabStop = false;
            // 
            // bulletz17
            // 
            this.bulletz17.Image = global::AAf.Properties.Resources.vecteezy_ai_generated_rocket_ship_on_transparent_background_37796417;
            this.bulletz17.Location = new System.Drawing.Point(542, 450);
            this.bulletz17.Name = "bulletz17";
            this.bulletz17.Size = new System.Drawing.Size(76, 103);
            this.bulletz17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bulletz17.TabIndex = 29;
            this.bulletz17.TabStop = false;
            // 
            // bulletz15
            // 
            this.bulletz15.Image = global::AAf.Properties.Resources.vecteezy_ai_generated_rocket_ship_on_transparent_background_37796417;
            this.bulletz15.Location = new System.Drawing.Point(323, 450);
            this.bulletz15.Name = "bulletz15";
            this.bulletz15.Size = new System.Drawing.Size(76, 103);
            this.bulletz15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bulletz15.TabIndex = 28;
            this.bulletz15.TabStop = false;
            // 
            // bulletz13
            // 
            this.bulletz13.Image = global::AAf.Properties.Resources.vecteezy_ai_generated_rocket_ship_on_transparent_background_37796417;
            this.bulletz13.Location = new System.Drawing.Point(112, 450);
            this.bulletz13.Name = "bulletz13";
            this.bulletz13.Size = new System.Drawing.Size(76, 103);
            this.bulletz13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bulletz13.TabIndex = 27;
            this.bulletz13.TabStop = false;
            // 
            // bulletz10
            // 
            this.bulletz10.Image = global::AAf.Properties.Resources.vecteezy_ai_generated_rocket_ship_on_transparent_background_37796417;
            this.bulletz10.Location = new System.Drawing.Point(433, 420);
            this.bulletz10.Name = "bulletz10";
            this.bulletz10.Size = new System.Drawing.Size(76, 103);
            this.bulletz10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bulletz10.TabIndex = 26;
            this.bulletz10.TabStop = false;
            // 
            // bulletz5
            // 
            this.bulletz5.Image = global::AAf.Properties.Resources.vecteezy_ai_generated_rocket_ship_on_transparent_background_37796417;
            this.bulletz5.Location = new System.Drawing.Point(542, 389);
            this.bulletz5.Name = "bulletz5";
            this.bulletz5.Size = new System.Drawing.Size(76, 103);
            this.bulletz5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bulletz5.TabIndex = 25;
            this.bulletz5.TabStop = false;
            // 
            // bulletz
            // 
            this.bulletz.Image = global::AAf.Properties.Resources.vecteezy_ai_generated_rocket_ship_on_transparent_background_37796417;
            this.bulletz.Location = new System.Drawing.Point(111, 389);
            this.bulletz.Name = "bulletz";
            this.bulletz.Size = new System.Drawing.Size(76, 103);
            this.bulletz.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bulletz.TabIndex = 24;
            this.bulletz.TabStop = false;
            // 
            // bulletz8
            // 
            this.bulletz8.Image = global::AAf.Properties.Resources.vecteezy_ai_generated_rocket_ship_on_transparent_background_37796417;
            this.bulletz8.Location = new System.Drawing.Point(216, 420);
            this.bulletz8.Name = "bulletz8";
            this.bulletz8.Size = new System.Drawing.Size(76, 103);
            this.bulletz8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bulletz8.TabIndex = 23;
            this.bulletz8.TabStop = false;
            // 
            // bulletz12
            // 
            this.bulletz12.Image = global::AAf.Properties.Resources.vecteezy_ai_generated_rocket_ship_on_transparent_background_37796417;
            this.bulletz12.Location = new System.Drawing.Point(643, 420);
            this.bulletz12.Name = "bulletz12";
            this.bulletz12.Size = new System.Drawing.Size(76, 103);
            this.bulletz12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bulletz12.TabIndex = 22;
            this.bulletz12.TabStop = false;
            // 
            // bulletz2
            // 
            this.bulletz2.Image = global::AAf.Properties.Resources.kisspng_rocket_stars_ships_planet_space_jigsaw_puzzles_gam_black_missile_rocket_5aa9c323309584_868663051521074979199;
            this.bulletz2.Location = new System.Drawing.Point(216, 389);
            this.bulletz2.Name = "bulletz2";
            this.bulletz2.Size = new System.Drawing.Size(75, 103);
            this.bulletz2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bulletz2.TabIndex = 21;
            this.bulletz2.TabStop = false;
            // 
            // bulletz3
            // 
            this.bulletz3.Image = global::AAf.Properties.Resources.vecteezy_ai_generated_rocket_ship_on_transparent_background_37796417;
            this.bulletz3.Location = new System.Drawing.Point(323, 389);
            this.bulletz3.Name = "bulletz3";
            this.bulletz3.Size = new System.Drawing.Size(76, 103);
            this.bulletz3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bulletz3.TabIndex = 20;
            this.bulletz3.TabStop = false;
            // 
            // money
            // 
            this.money.Image = global::AAf.Properties.Resources.kisspng_bitcoin_cryptocurrency_monero_initial_coin_offerin_bitcoin_5abdfe6babbd25_0459423215224008757035;
            this.money.Location = new System.Drawing.Point(306, 338);
            this.money.Name = "money";
            this.money.Size = new System.Drawing.Size(30, 27);
            this.money.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.money.TabIndex = 18;
            this.money.TabStop = false;
            // 
            // money2
            // 
            this.money2.Image = global::AAf.Properties.Resources.kisspng_bitcoin_cryptocurrency_monero_initial_coin_offerin_bitcoin_5abdfe6babbd25_0459423215224008757035;
            this.money2.Location = new System.Drawing.Point(483, 338);
            this.money2.Name = "money2";
            this.money2.Size = new System.Drawing.Size(30, 27);
            this.money2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.money2.TabIndex = 17;
            this.money2.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::AAf.Properties.Resources.kisspng_bitcoin_cryptocurrency_monero_initial_coin_offerin_bitcoin_5abdfe6babbd25_0459423215224008757035;
            this.pictureBox5.Location = new System.Drawing.Point(-2, 33);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(30, 27);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 10;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::AAf.Properties.Resources.transparent_red_heart_ornament_love_heart_5de1a858e9d5f9_9211270915750697849578;
            this.pictureBox4.Location = new System.Drawing.Point(-2, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(30, 27);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 9;
            this.pictureBox4.TabStop = false;
            // 
            // emdad1
            // 
            this.emdad1.Image = global::AAf.Properties.Resources.kisspng_robot_vehicle_5b3b1951d2f642_4602919815305997618641;
            this.emdad1.Location = new System.Drawing.Point(344, 243);
            this.emdad1.Name = "emdad1";
            this.emdad1.Size = new System.Drawing.Size(126, 122);
            this.emdad1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.emdad1.TabIndex = 13;
            this.emdad1.TabStop = false;
            // 
            // bullet
            // 
            this.bullet.Image = global::AAf.Properties.Resources.kisspng_glass_transparency_and_translucency_sphere_crystal_magic_ball_5a9710ca74fa97_8178885115198496744792;
            this.bullet.Location = new System.Drawing.Point(398, 944);
            this.bullet.Name = "bullet";
            this.bullet.Size = new System.Drawing.Size(41, 52);
            this.bullet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bullet.TabIndex = 12;
            this.bullet.TabStop = false;
            // 
            // player
            // 
            this.player.Image = global::AAf.Properties.Resources.kisspng_starcraft_ii_legacy_of_the_void_protoss_wikia_zer_zerg_5b31b2daa114e3_5278638215299837066598;
            this.player.Location = new System.Drawing.Point(367, 931);
            this.player.Name = "player";
            this.player.Size = new System.Drawing.Size(103, 99);
            this.player.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.player.TabIndex = 11;
            this.player.TabStop = false;
            // 
            // boss1
            // 
            this.boss1.Image = global::AAf.Properties.Resources.kisspng_star_citizen_hawk_hildesheim_holzminden_goettingen_star_citizen_5b4d11b130b358_2715229715317774571995;
            this.boss1.Location = new System.Drawing.Point(34, 0);
            this.boss1.Name = "boss1";
            this.boss1.Size = new System.Drawing.Size(770, 237);
            this.boss1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.boss1.TabIndex = 8;
            this.boss1.TabStop = false;
            // 
            // enemyThree
            // 
            this.enemyThree.Image = global::AAf.Properties.Resources.kisspng_starcraft_ii_wings_of_liberty_starcraft_remaster_carrier_5add3f29d9ff11_8314436615244490658929;
            this.enemyThree.Location = new System.Drawing.Point(657, 0);
            this.enemyThree.Name = "enemyThree";
            this.enemyThree.Size = new System.Drawing.Size(91, 99);
            this.enemyThree.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemyThree.TabIndex = 7;
            this.enemyThree.TabStop = false;
            // 
            // enemyFour
            // 
            this.enemyFour.Image = global::AAf.Properties.Resources.kisspng_concept_art_starcraft_terran_starcraft_5b342ed24f6fa5_0844313515301465143254;
            this.enemyFour.Location = new System.Drawing.Point(540, 0);
            this.enemyFour.Name = "enemyFour";
            this.enemyFour.Size = new System.Drawing.Size(91, 99);
            this.enemyFour.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemyFour.TabIndex = 6;
            this.enemyFour.TabStop = false;
            // 
            // enemyFive
            // 
            this.enemyFive.Image = global::AAf.Properties.Resources.kisspng_spacecraft_starship_alien_alien_spaceship_5ae81407e1c996_8776167715251589199248__2_;
            this.enemyFive.Location = new System.Drawing.Point(422, 0);
            this.enemyFive.Name = "enemyFive";
            this.enemyFive.Size = new System.Drawing.Size(91, 99);
            this.enemyFive.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemyFive.TabIndex = 5;
            this.enemyFive.TabStop = false;
            // 
            // enemySix
            // 
            this.enemySix.Image = global::AAf.Properties.Resources.kisspng_fighter_aircraft_3d_computer_graphics_dax_daily_he_flipbook_effect_5b50cb1eca2fe7_3493464515320215348282;
            this.enemySix.Location = new System.Drawing.Point(306, 0);
            this.enemySix.Name = "enemySix";
            this.enemySix.Size = new System.Drawing.Size(91, 99);
            this.enemySix.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemySix.TabIndex = 4;
            this.enemySix.TabStop = false;
            // 
            // enemyTwo
            // 
            this.enemyTwo.Image = global::AAf.Properties.Resources.kisspng_starcraft_ii_wings_of_liberty_starcraft_ii_nova_5b0ac38b5debf4_4344944315274320753847;
            this.enemyTwo.Location = new System.Drawing.Point(188, 0);
            this.enemyTwo.Name = "enemyTwo";
            this.enemyTwo.Size = new System.Drawing.Size(91, 99);
            this.enemyTwo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemyTwo.TabIndex = 3;
            this.enemyTwo.TabStop = false;
            // 
            // enemyOne
            // 
            this.enemyOne.Image = global::AAf.Properties.Resources.kisspng_starcraft_brood_war_starcraft_ii_wings_of_libert_creative_spaceship_5b08a8dc517ca4_6787656115272941723338;
            this.enemyOne.Location = new System.Drawing.Point(69, 0);
            this.enemyOne.Name = "enemyOne";
            this.enemyOne.Size = new System.Drawing.Size(91, 99);
            this.enemyOne.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemyOne.TabIndex = 2;
            this.enemyOne.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::AAf.Properties.Resources.kisspng_white_line_ru_paul_5b16a3d8c44597_3372234515282103928039;
            this.pictureBox1.Location = new System.Drawing.Point(-2, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(882, 500);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::AAf.Properties.Resources.kisspng_white_line_ru_paul_5b16a3d8c44597_3372234515282103928039;
            this.pictureBox2.Location = new System.Drawing.Point(-2, 498);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(882, 523);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::AAf.Properties.Resources.kisspng_earth_supermoon_full_moon_the_moon_png_5ab035f631f4a5_8111196515214975902046;
            this.pictureBox3.Location = new System.Drawing.Point(624, 243);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(82, 79);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 49;
            this.pictureBox3.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(875, 1018);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.txtCoin);
            this.Controls.Add(this.txtHeart);
            this.Controls.Add(this.boss1);
            this.Controls.Add(this.sun);
            this.Controls.Add(this.Nplayer2);
            this.Controls.Add(this.Nplayer1);
            this.Controls.Add(this.BlackMagic);
            this.Controls.Add(this.Magic);
            this.Controls.Add(this.pbullet);
            this.Controls.Add(this.fire);
            this.Controls.Add(this.exp4);
            this.Controls.Add(this.exp3);
            this.Controls.Add(this.exp2);
            this.Controls.Add(this.exp1);
            this.Controls.Add(this.bulletz18);
            this.Controls.Add(this.bulletz7);
            this.Controls.Add(this.bulletz6);
            this.Controls.Add(this.bulletz4);
            this.Controls.Add(this.bulletz16);
            this.Controls.Add(this.bulletz11);
            this.Controls.Add(this.bulletz14);
            this.Controls.Add(this.bulletz9);
            this.Controls.Add(this.bulletz17);
            this.Controls.Add(this.bulletz15);
            this.Controls.Add(this.bulletz13);
            this.Controls.Add(this.bulletz10);
            this.Controls.Add(this.bulletz5);
            this.Controls.Add(this.bulletz);
            this.Controls.Add(this.bulletz8);
            this.Controls.Add(this.bulletz12);
            this.Controls.Add(this.bulletz2);
            this.Controls.Add(this.bulletz3);
            this.Controls.Add(this.money);
            this.Controls.Add(this.money2);
            this.Controls.Add(this.emdad1);
            this.Controls.Add(this.bullet);
            this.Controls.Add(this.player);
            this.Controls.Add(this.enemyThree);
            this.Controls.Add(this.enemyFour);
            this.Controls.Add(this.enemyFive);
            this.Controls.Add(this.enemySix);
            this.Controls.Add(this.enemyTwo);
            this.Controls.Add(this.enemyOne);
            this.Controls.Add(this.txtScore);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keyisdown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.keyisup);
            ((System.ComponentModel.ISupportInitialize)(this.sun)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Nplayer2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Nplayer1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackMagic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Magic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbullet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fire)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.exp4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.exp3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.exp2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.exp1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bulletz3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.money)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.money2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emdad1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bullet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.boss1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyThree)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyFour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyFive)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemySix)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyTwo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyOne)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox enemyOne;
        private System.Windows.Forms.PictureBox enemyTwo;
        private System.Windows.Forms.PictureBox enemySix;
        private System.Windows.Forms.PictureBox enemyFive;
        private System.Windows.Forms.PictureBox enemyFour;
        private System.Windows.Forms.PictureBox enemyThree;
        private System.Windows.Forms.PictureBox boss1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox player;
        private System.Windows.Forms.PictureBox bullet;
        private System.Windows.Forms.PictureBox emdad1;
        private System.Windows.Forms.Label txtScore;
        private System.Windows.Forms.Timer gameTimer;
        private System.Windows.Forms.Label txtHeart;
        private System.Windows.Forms.Label txtCoin;
        private System.Windows.Forms.PictureBox money2;
        private System.Windows.Forms.PictureBox money;
        private System.Windows.Forms.PictureBox bulletz3;
        private System.Windows.Forms.PictureBox bulletz2;
        private System.Windows.Forms.PictureBox bulletz12;
        private System.Windows.Forms.PictureBox bulletz8;
        private System.Windows.Forms.PictureBox bulletz;
        private System.Windows.Forms.PictureBox bulletz5;
        private System.Windows.Forms.PictureBox bulletz10;
        private System.Windows.Forms.PictureBox bulletz13;
        private System.Windows.Forms.PictureBox bulletz15;
        private System.Windows.Forms.PictureBox bulletz17;
        private System.Windows.Forms.PictureBox bulletz9;
        private System.Windows.Forms.PictureBox bulletz14;
        private System.Windows.Forms.PictureBox bulletz11;
        private System.Windows.Forms.PictureBox bulletz16;
        private System.Windows.Forms.PictureBox bulletz4;
        private System.Windows.Forms.PictureBox bulletz6;
        private System.Windows.Forms.PictureBox bulletz7;
        private System.Windows.Forms.PictureBox bulletz18;
        private System.Windows.Forms.PictureBox exp1;
        private System.Windows.Forms.PictureBox exp2;
        private System.Windows.Forms.PictureBox exp3;
        private System.Windows.Forms.PictureBox exp4;
        private System.Windows.Forms.PictureBox fire;
        private System.Windows.Forms.PictureBox pbullet;
        private System.Windows.Forms.PictureBox Magic;
        private System.Windows.Forms.PictureBox BlackMagic;
        private System.Windows.Forms.PictureBox Nplayer1;
        private System.Windows.Forms.PictureBox Nplayer2;
        private System.Windows.Forms.PictureBox sun;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}

